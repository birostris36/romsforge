from remap_module import process_files
import argparse
import os


def main():
    parser = argparse.ArgumentParser(description="Remap 15km ROMS output to 5km grid using precomputed weights.")
    parser.add_argument('--avg_dir', required=True, help='Directory of 15km average NetCDF files')
    parser.add_argument('--grid01', required=True, help='Path to 15km grid01.nc')
    parser.add_argument('--grid02', required=True, help='Path to 5km grid02.nc')
    parser.add_argument('--weight_rho', required=True, help='Weight file for rho points')
    parser.add_argument('--weight_u', required=True, help='Weight file for u points')
    parser.add_argument('--weight_v', required=True, help='Weight file for v points')
    parser.add_argument('--output_dir', required=True, help='Directory to save remapped 5km files')

    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    weight_paths = {
        'rho': args.weight_rho,
        'u': args.weight_u,
        'v': args.weight_v
    }

    process_files(
        avg_dir=args.avg_dir,
        grid01=args.grid01,
        grid02=args.grid02,
        weight_paths=weight_paths,
        output_dir=args.output_dir
    )


if __name__ == '__main__':
    main()
