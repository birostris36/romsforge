
#!/bin/sh
# ==== PBS SETTINGS ====
#PBS -q workq
#PBS -l nodes=ust12:ppn=48+ust13:ppn=32,walltime=100:00:00
###PBS -l nodes=ust12:ppn=48,walltime=100:00:00
#PBS -N a_isl
#PBS -o .
#PBS -e .
###PBS -o /home/shjo/laboratory/roms/roms_820_nemucsc_latest_modi/cases/i4dvar01/log_pbs/build_roms.o$PBS_JOBID
MPI_IMPL=mvapich2
NP=$(wc -l < "$PBS_NODEFILE")
set -eu # Script setting

# ---- PBS info ----
JOBID=${PBS_JOBID:-unknown}
WORKDIR="${PBS_O_WORKDIR:-$PWD}"
cd "$WORKDIR" || { echo "[ERR] cd error: $WORKDIR"; exit 1; }
: "${PBS_NODEFILE:?PBS_NODEFILE not defined}"

echo "[$JOBID] Running on:"
uniq "$PBS_NODEFILE" | while IFS= read -r n; do echo "  - $n"; done
echo "Start directory: $WORKDIR"
echo "Nodes: $(uniq "$PBS_NODEFILE" | wc -l), Cores: $(wc -l < "$PBS_NODEFILE")"

# ==== DEFINE PYTHON  ====
CONDA_HOME="/usr/local/anaconda3" 
# ---- python config file ----
isl_dir="/home/shjo/ROMS/romsforge/postproc/packages/nifs01"
config_isl_h2l="${isl_dir}/config_isl_h2l.template" 
config_isl_l2h="${isl_dir}/config_isl_l2h.template" 
# ---- python run file ----
python_scrpt01="${isl_dir}/calc_add_incre.py" 
python_scrpt02="${isl_dir}/roms2roms.py" 

# ==== DEFINE LOCAL VARIABLES ====
# ---- directories ----
case_name="test_isl_mpv2"
app_dir="/data/shjo/applications/nifs01_test"
roms_dir="/home/shjo/ROMS/ROMS_latest_v2B"
data_dir="$app_dir/storage/data"

# ---- auto define ----
readonly case_dir="$app_dir/storage/$case_name"
readonly trunk="$case_dir/trunk"
readonly storage_da="$case_dir/da"
readonly storage_nl="$case_dir/nl"
mkdir -p "$case_dir" "$trunk" "$storage_da" "$storage_nl"

# ---- input files for ROMS ----
first_guess_da="$data_dir/NWP4_ini_3_10m_LP_standard.nc"
first_guess_nl="$data_dir/NWP12_ini_NWP4.nc"

nrmname="$data_dir/NWP4_nrm_i.nc"
stdname="null"
obsname="$data_dir/NWP4_obs_sst_EN4_kodc_23_24.nc"

romsM_da="execM_da"
romsM_nl="execM_nl"

infile_fixed_da="$app_dir/da_infile.template"
infile_fixed_nl="$app_dir/nl_infile.template"

readonly infile_template_da="$app_dir/da_ocean.tmp"
readonly infile_template_nl="$app_dir/nl_ocean.tmp"

prefix_da="wnp25km"
prefix_nl="wnp8km"

readonly infile_da="da_${prefix_da}.in"
readonly infile_nl="nl_${prefix_nl}.in"

i4dvar_template="s4dvar.in"  
i4dvar_infile="i4dvar.in"

GRDNAME_DA="$data_dir/NWP4_grd_3_10m_LP.nc"
GRDNAME_NL="$data_dir/NWP12_grd_NWP4.nc"

BRYNAME_DA="$data_dir/NWP4_bry_3_10m_LP.nc"
BRYNAME_NL="$data_dir/NWP12_bry_NWP4.nc"

SSFNAME_NL="$data_dir/roms_river_NWP12_2023_modi_time.nc"
TIDENAME_NL="$data_dir/tide_h.nc"

FRCNAME_DA="$data_dir/frc.nc"
FRCNAME_NL="$FRCNAME_DA"

readonly ININAME_DA="${prefix_da}_ini.nc"
readonly ININAME_NL="${prefix_nl}_ini.nc"
readonly RSTNAME_DA="${prefix_da}_RST_DA.nc"
readonly RSTNAME_NL="${prefix_nl}_RST_DA.nc"

VARINFO_DA="/home/shjo/ROMS/ROMS_latest_v2B/varinfo/varinfo.dat"
VARINFO_NL="$VARINFO_DA"

# ==== DEFINE & EXPORT CONSTANTS TO INFILES =====
TITLE_DA="Western north Pacific 25km ISL system (case: "${case_name}")"
TITLE_NL="Western north Pacific 8km ISL system (case: "${case_name}")"

DAY_START=8401
DAY_END=8522
TIME_REF=20000101

DAYSTEP=4 # [days]
DT_DA=480        # [s]
DT_NL=200        # [s]

NTILEI=10
NTILEJ=8
NOUTER=1
NINNER=12

# ---- automatically calculates nHIS for infile ---- 
NRST_DA=$(( (86400 / DT_DA) * DAYSTEP ))
NRST_NL=$(( (86400 / DT_NL) * DAYSTEP ))
[ $((86400 % DT_DA)) -eq 0 ] || echo "[warn] 86400/DT_DA 나머지 있음"
[ $((86400 % DT_NL)) -eq 0 ] || echo "[warn] 86400/DT_NL 나머지 있음"

# ---- export and fix environmental variables ----
(
  export DAY_START DAY_END TIME_REF \
         DAYSTEP DT_DA DT_NL \
         NTILEI NTILEJ NOUTER NINNER \
         NRST_DA NRST_NL \
         TITLE_DA TITLE_NL \
         GRDNAME_NL GRDNAME_DA \
         ININAME_NL ININAME_DA \
         BRYNAME_NL BRYNAME_DA \
         RSTNAME_NL RSTNAME_DA \
         SSFNAME_NL TIDENAME_NL \
         FRCNAME_NL FRCNAME_DA \
         VARINFO_DA VARINFO_NL 

  export TRUNK=$trunk

  # ---- apply to python config files ----
  envsubst '
  $GRDNAME_DA $GRDNAME_NL $ININAME_NL $ININAME_DA $TRUNK
  ' < "$config_isl_l2h" > "${isl_dir}/config_isl_l2h.yaml"
  envsubst '
  $GRDNAME_DA $GRDNAME_NL $RSTNAME_NL $RSTNAME_DA $TRUNK
  ' < "$config_isl_h2l" > "${isl_dir}/config_isl_h2l.yaml"

  # ---- apply to infiles ---- 
  envsubst '
  $GRDNAME_DA $ININAME_DA $BRYNAME_DA $VARINFO_DA $TRUNK
  $TITLE_DA $DAY_START $DAY_END $TIME_REF $DAYSTEP $DT_DA
  $NTILEI $NTILEJ $NOUTER $NINNER $NRST_DA
  ' < "$infile_fixed_da" > "$infile_template_da"
  envsubst '
  $GRDNAME_NL $ININAME_NL $BRYNAME_NL $SSFNAME_NL $VARINFO_NL
  $TITLE_NL $DAY_START $DAY_END $TIME_REF $DAYSTEP $DT_NL
  $NTILEI $NTILEJ $NRST_NL $NOUTER $NINNER $TRUNK
  ' < "$infile_fixed_nl" > "$infile_template_nl"

#  grep -Eq '\$\{[^}]+\}' "$infile_template_da" && { echo "[ERR] 미치환 변수: $infile_template_da"; exit 1; }
#  grep -Eq '\$\{[^}]+\}' "$infile_template_nl" && { echo "[ERR] 미치환 변수: $infile_template_nl"; exit 1; }
)
# ==== DEFAULT SETTINS FOR LOOP =====
cycle=0
datenum="$DAY_START"


itlname_da="${prefix_da}_itl_${datenum}.nc"

# ==== DEFINE FUNCTIONS / MODULES ====
# ---- module for i4dvar.in ----
render_i4dvar_in() {
  (
    set -a 
    STDNAME="$stdname"
    NRMNAME="$nrmname"
    HSSNAME="${prefix_da}_hss_${datenum}.nc"
    OBSNAME="$obsname"
    MODNAME="${prefix_da}_mod_${datenum}.nc"

    envsubst '$STDNAME $NRMNAME $HSSNAME $OBSNAME $MODNAME' \
      < "$i4dvar_template" > "$i4dvar_infile"
  ) || { echo "[ERR] envsubst 실패: i4dvar"; return 1; }

#  grep -q  '\${[^}]\{1,\}}' "$i4dvar_infile" && {
#    echo "[ERR] 미치환 변수 있음: $i4dvar_infile"; return 1; }
}

# ---- module for da model infile ----
render_da_in() {
  (
    set -a
    FWDNAME="${prefix_da}_fwd_${datenum}.nc"
    RSTNAME="${prefix_da}_rst_${datenum}.nc"
    HISNAME="${prefix_da}_his_${datenum}.nc"
    AVGNAME="${prefix_da}_avg_${datenum}.nc"
    TLMNAME="${prefix_da}_tlm_${datenum}.nc"
    ADJNAME="${prefix_da}_adj_${datenum}.nc"

    DSTART="${datenum}.0d0"

    ITLNAME="$itlname_da"

    IS4DVAR_PARAM="$i4dvar_infile"

    envsubst '$DSTART $ITLNAME $FWDNAME $RSTNAME $HISNAME $AVGNAME $TLMNAME $ADJNAME $IS4DVAR_PARAM' \
      < "$infile_template_da" > "$infile_da"
  ) || { echo "[ERR] envsubst 실패: da_ocean"; return 1; }

#  grep -q  '\${[^}]\{1,\}}' "$infile_da" && {
#    echo "[ERR] 미치환 변수 있음: $infile_da"; return 1; }
}

# --- module for nonlinear model infile ---
render_nl_in() {
  (
    set -a
    RSTNAME="${prefix_nl}_rst_${datenum}.nc"
    HISNAME="${prefix_nl}_his_${datenum}.nc"
    AVGNAME="${prefix_nl}_avg_${datenum}.nc"

    DSTART="${datenum}.0d0"

    envsubst '$DSTART $RSTNAME $HISNAME $AVGNAME' \
      < "$infile_template_nl" > "$infile_nl"
  ) || { echo "[ERR] envsubst 실패: nl_ocean"; return 1; }

#  grep -q  '\${[^}]\{1,\}}' "$infile_nl" && {
#    echo "[ERR] 미치환 변수 있음: $infile_nl"; return 1; }
}

source /etc/profile.d/modules.sh 2>/dev/null || true
ulimit -s unlimited
export OMP_NUM_THREADS=1

module purge
if [ "${MPI_IMPL:-mvapich2}" = "mvapich2" ]; then
  echo "env: $MPI_IMPL"
  export MV2_ENABLE_AFFINITY=0
  #export MV2_CPU_BINDING_POLICY=spread   # 바인딩 분산
  export MV2_SHOW_CPU_BINDING=1
  export MV2_SMP_USE_CMA=0
  export HDF5_USE_FILE_LOCKING=FALSE      # 파일 잠금 비활성(병렬 FS/NFS에서 hang 방지)
  export HDF5_COLL_METADATA_WRITE=0       # 메타데이터 집단 쓰기 비활성
  module load intel19/compiler-19
  module load intel19/mvapich2-2.3.4
  #module load intel19/netcdf-3.6.3   # ← 빌드셋에 맞춰 조정
  module load intel19/netcdf-4.6.1   # ← 빌드셋에 맞춰 조정
else
  echo "env: $MPI_IMPL"
  module load intel19/compiler-19
  module load intel19/openmpi-3.1.6
  module load intel19/netcdf-4.6.1   # ← 위와 통일 권장
fi
#command -v mpirun >/dev/null || { echo "[ERR] mpirun 없음"; exit 1; }
#mpirun --version | head -1

# ==== MAIN LOOP ====
while [ "$datenum" -le "$DAY_END" ]; do
  cycle=$((cycle+1))
  echo ">>>"
  echo ">>> Starting data assimilation cycle: $cycle (DAY=$datenum)"

  cd "$app_dir/I4DVAR"
  rm -f ./*.nc 2>/dev/null || true

  itlname_da=${prefix_da}_itl_${datenum}.nc

  if [ "$datenum" -eq "$DAY_START" ]; then
    cp -fp "$first_guess_da" "$ININAME_DA"
  else
    cp -fp "$trunk/$ININAME_DA" .
  fi
  echo ">>> select appropriate std file automatically"
  # ---- select appropriate std file automatically ----
  ref_clean=${TIME_REF%%.*}  # ".0d0" 같은 꼬리 제거
  case "$ref_clean" in
    ????-??-??) ref_iso="$ref_clean" ;;                                  # 2024-01-01
    ????????)   ref_iso="${ref_clean:0:4}-${ref_clean:4:2}-${ref_clean:6:2}" ;;  # 20240101
    *) echo "[ERR] TIME_REF 형식 오류: $TIME_REF"; exit 1 ;;
  esac
  mon_abbr=$(LC_ALL=C date -u -d "${ref_iso} + ${datenum} days" +%b | tr '[:upper:]' '[:lower:]')
  stdname="${data_dir}/std/NWP4_std_i_${mon_abbr}_70.nc"
  [ -f "$stdname" ] || { echo "[ERR] STD 파일 없음: $stdname"; exit 1; }

  echo ">>> create i4dvar.in "
  # ---- create i4dvar.in (envsubst) ----
  render_i4dvar_in || exit 1

  echo ">>> create da infile"
  # ---- create da infile (envsubst) ----
  render_da_in     || exit 1

  echo ">>> Running I4DVAR algorithm, starting day: $datenum"
  # ==== Run incremental 4DVar algorithm ====
  if [ -e da_log.prt ]; then
    /bin/rm -f da_log.prt
  fi

  echo " >>> Run da model (core num: $NP)"
  # ---- run da model ----

  if [ "${MPI_IMPL:-mvapich2}" = "mvapich2" ]; then
    mpirun -f "$PBS_NODEFILE" -n "$NP" \
        -genv MV2_ENABLE_AFFINITY 0 \
        "$romsM_da" "$infile_da" > da_log.prt
  else # openmpi
    mpirun -np $NP \
      --hostfile $PBS_NODEFILE \
      --map-by slot \
      --bind-to core \
      --report-bindings \
      $romsM_da $infile_da  > da_log.prt
  fi

  echo ">>> Move output files to storage (da)"
  # ---- move output files to storage (da) ----
  cp -f "$ININAME_DA" "$trunk/$ININAME_DA"
  mv -f "$ININAME_DA" "${storage_da}/${prefix_da}_ini_DA_${datenum}.nc"
  mv -f "${prefix_da}_mod_${datenum}.nc" "$storage_da"
  mv -f ${prefix_da}_fwd_*.nc "$storage_da"
  mv -f ${prefix_da}_hss_*.nc "$storage_da"
  mv -f "da_log.prt" "$storage_da/da_log.${datenum}"

  echo ">>>  copy First guess from Forward run"
  # ---- copy First guess from Forward run ----
  if [ $datenum -eq $DAY_START ]; then
    cp -p "${first_guess_nl}" "${trunk}/${ININAME_NL}"
  fi
  
  echo ">>> calculates increment and applies it to first guess from nonlinear model"
  # ---- calculates increment and applies it to first guess from nonlinear model ----
  "$CONDA_HOME/bin/conda" run -n romsforge --no-capture-output python $python_scrpt01 

#    export MLM_LICENSE_FILE=/home/shjo/.matlab/R2024a_licenses/license_ust11_41263416_R2024a.lic
#    export MATLAB_DIR=/usr/local/MATLAB/R2024a/bin
#    wdr=/data/shjo/applications/nifs01_test/matlab_codes
#    nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/calc_increment.m'); exit" > ./matlab1.log 2>&1
#   nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/interpolate_increment_L2H.m'); exit" > ./matlab2.log 2>&1
#   nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/joint_increment.m'); exit" > ./matlab3.log 2>&1

  echo ">>> copy high resolution initial condition to storage (nl) as a back up"
  # ---- copy high resolution initial condition to storage (nl) as a back up ----
  cp "${trunk}/${ININAME_NL}" "$storage_nl/${prefix_nl}_ini_DA_${datenum}.nc"
  #cp "${trunk}/${ININAME_NL}" "$storage_nl/${prefix_nl}_ini_DA_incre_${datenum}.nc"
  
  # ---- copy low resolution model increment as a back up ----
  #cp "${trunk}/${prefix_da}_ini_DA_incre.nc" "$storage_da/${prefix_da}_ini_DA_incre_${datenum}.nc"

  #---------------------------------------------------------------------
  # Run Nonlinear model initialized with 4DVAR estimated initial
  # conditions for the period of the assimilation time window. It
  # will compute the first guess for the next assimilation cycle
  #---------------------------------------------------------------------
  cd "$app_dir/Forward"

  echo ">>> Create nl infile"
  # ---- Create nl infile ----
  render_nl_in     || exit 1

  echo ">>> Running nonlinear model, starting day: $datenum"
  # ---- Run nonlinear ROMS ----

  if [ -e nl_log.prt ]; then
    /bin/rm -f nl_log.prt
  fi

  if [ "${MPI_IMPL:-mvapich2}" = "mvapich2" ]; then
    mpirun -f "$PBS_NODEFILE" -n "$NP" \
        -genv MV2_ENABLE_AFFINITY 0 \
        "$romsM_nl" "$infile_nl" > nl_log.prt
  else # openmpi
    mpirun -np $NP \
      --hostfile $PBS_NODEFILE \
      --map-by slot \
      --bind-to core \
      --report-bindings \
      $romsM_nl $infile_nl  > nl_log.prt
  fi

  echo ">>> Move current nonlinear history and log files to storage "
  # ---- Move current nonlinear history and log files to storage ----
  #mv -f ${prefix_nl}_his_${datenum}*.nc "${storage_nl}"
  mv -f ${prefix_nl}_avg_${datenum}*.nc "${storage_nl}"
  mv -f "nl_log.prt" "$storage_nl/nl_log.${datenum}"

  echo ">>> copy RST from high resolution model rst file to interpolation file"
  # ---- copy RST from high resolution model rst file to interpolation file
  # for coarse model initial condition for next DA cycle ----
  cp -f "$app_dir/Forward/${prefix_nl}_rst_${datenum}.nc" "$trunk/${RSTNAME_NL}"
  cp -f "$app_dir/Forward/${prefix_nl}_rst_${datenum}.nc" "$trunk/$ININAME_NL"
  mv -f "${prefix_nl}_rst_${datenum}.nc" "${storage_nl}"
  #---------------------------------------------------------------------
  # Advance starting day for next assimilation cycle. Set new initial
  # conditions file name.
  #---------------------------------------------------------------------
  datenum=$((datenum + DAYSTEP))

  echo ">>> H -> L interpolation"
  "$CONDA_HOME/bin/conda" run -n romsforge --no-capture-output python $python_scrpt02 

  #nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/interpolate_increment_H2L.m'); exit" > ./matlab4.log 2>&1
  #---------------------------------------------------------------------
  # Move next cycle first guess (background state) to storage. It is
  # currently stored in the restart file.
  #---------------------------------------------------------------------
  cd "$app_dir/Forward"

  cp -f "$trunk/${RSTNAME_DA}" "${storage_da}/${prefix_da}_ini_${prefix_nl}_Fwd_${datenum}.nc"
  mv -f "$trunk/${RSTNAME_DA}" "$trunk/${ININAME_DA}"
  #---------------------------------------------------------------------
  # Move next cycle hignlolution model first guess
  # (initial file) to input storage.
  #---------------------------------------------------------------------

  echo "  "
  echo ">>> Finished data assimilation cycle: $cycle"
  echo "  "
  echo "  "
done





























