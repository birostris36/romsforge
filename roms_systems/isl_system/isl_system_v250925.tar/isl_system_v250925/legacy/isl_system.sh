
#!/bin/sh

# >>> PBS settings
#PBS -q workq
#PBS -l nodes=nft00:ppn=4,walltime=100:00:00
#PBS -N build_roms
#PBS -j oe
#PBS -o /home/shjo/laboratory/roms/roms_820_nemucsc_latest_modi/cases/i4dvar01/log_pbs/build_roms.o$PBS_JOBID

set -eu

JOBID=${PBS_JOBID:-unknown}
WORKDIR="${PBS_O_WORKDIR:-$PWD}"
cd "$WORKDIR" || { echo "[ERR] cd error: $WORKDIR"; exit 1; }
: "${PBS_NODEFILE:?PBS_NODEFILE not defined}"

echo "[$JOBID] Running on:"
uniq "$PBS_NODEFILE" | while IFS= read -r n; do echo "  - $n"; done
echo "Start directory: $WORKDIR"
echo "Nodes: $(uniq "$PBS_NODEFILE" | wc -l), Cores: $(wc -l < "$PBS_NODEFILE")"

#>>> Miniconda env
CONDA_HOME="/usr/local/miniconda3" ; readonly CONDA_HOME

# >>> Define environmental variables
case_name="test_isl"
app_dir="/home/shjo/ROMS/ROMS_latest_v2B/project/ISL_70control"
roms_dir="/home/shjo/ROMS/ROMS_latest_v2B"
data_dir="$app_dir/storage/data"

# --- Auto define ---
case_dir="$app_dir/storage/$case_name"
trunk="$case_dir/trunk"
storage_lres="$case_dir/lres"
storage_hres="$case_dir/hres"
mkdir -p "$case_dir" "$trunk" "$storage_lres" "$storage_hres"
# <<< Define environmental variables

# >>> Define inputs
grdname_lres="$data_dir/tmp_grd_l.nc"
grdname_hres="$data_dir/tmp_grd_h.nc"

first_guess_lres="$data_dir/tmp_ini_l.nc"
first_guess_hres="$data_dir/tmp_ini_h.nc"

bryname_lres="$data_dir/tmp_bry_l.nc"
bryname_hres="$data_dir/tmp_bry_h.nc"

ssfname_hres="$data_dir/river_h.nc"
tidename_hres="$data_dir/tide_h.nc"

frcname_lres="$data_dir/frc.nc"
frcname_hres="$frcname_lres"

nrmname="$data_dir/nrm.nc"
stdname="null"
obsname="$data_dir/obs.nc"
# <<< Define inputs

# >>> Define files name
romsM_lres="execM_da"
romsM_hres="execM_nl"

infile_fixed_lres="$app_dir/da_ocean.fix"
infile_fixed_hres="$app_dir/nl_ocean.fix"

infile_template_lres="$app_dir/da_ocean.tmp"
infile_template_hres="$app_dir/nl_ocean.tmp"

prefix_lres="wnp25km"
prefix_hres="wnp8km"


infile_lres="da_${prefix_lres}.in"
infile_hres="nl_${prefix_hres}.in"

varinfo_lres="varinfo.dat"
varinfo_hres="$varinfo_lres"

i4dvar_template="s4dvar.in"   # 템플릿은 .tmp로 권장
i4dvar_infile="i4dvar.in"
# <<< Define files name

# ===== 설정 상수(대문자 + readonly) =====
TITLE_LRES="Western north Pacific 25km ISL system (case: "${case_name}")"
TITLE_HRES="Western north Pacific 8km ISL system (case: "${case_name}")"

DAY_START=15706
DAY_END=15707
TIME_REF="2000-01-01"

DAYSTEP=8          # [days]
DT_LRES=200        # [s]
DT_HRES=120        # [s]

NTILEI=8
NTILEJ=8
NOUTER=1
NINNER=12

# 파생 상수(한 번 계산)
NRST_LRES=$(( (86400 / DT_LRES) * DAYSTEP ))
NRST_HRES=$(( (86400 / DT_HRES) * DAYSTEP ))

# 정합성 경고(선택)
[ $((86400 % DT_LRES)) -eq 0 ] || echo "[warn] 86400/DT_LRES 나머지 있음"
[ $((86400 % DT_HRES)) -eq 0 ] || echo "[warn] 86400/DT_HRES 나머지 있음"

# ===== 한 번에 export =====
export DAY_START DAY_END TIME_REF \
       DAYSTEP DT_LRES DT_HRES \
       NTILEI NTILEJ NOUTER NINNER \
       NRST_LRES NRST_HRES \
       TITLE_LRES TITLE_HRES

# ===== 더 못 바꾸게 잠그고 싶으면 =====
readonly DAY_START DAY_END TIME_REF \
         DAYSTEP DT_LRES DT_HRES \
         NTILEI NTILEJ NOUTER NINNER \
         NRST_LRES NRST_HRES \
         TITLE_LRES TITLE_HRES

envsubst '$TITLE_LRES,$DAY_START,$DAY_END,$TIME_REF,$DAYSTEP,$DT_LRES,$NTILEI,$NTILEJ,$NOUTER,$NINNER,$NRST_LRES' \
  < "$infile_fixed_lres" > "$infile_template_lres"
envsubst '$TITLE_HRES,$DAY_START,$DAY_END,$TIME_REF,$DAYSTEP,$DT_HRES,$NTILEI,$NTILEJ,$NRST_HRES' \
  < "$infile_fixed_hres" > "$infile_template_hres"


grep -Eq '\$\{[^}]+\}' "$infile_template_lres" && { echo "[ERR] 미치환 변수: $infile_template_lres"; exit 1; }
grep -Eq '\$\{[^}]+\}' "$infile_template_hres" && { echo "[ERR] 미치환 변수: $infile_template_hres"; exit 1; }

# ===== 런타임 상태(소문자) =====
cycle=0
datenum="$DAY_START"

ininame_lres="${prefix_lres}_ini.nc"
ininame_hres="${prefix_hres}_ini.nc"
itlname_lres="${prefix_lres}_itl_${datenum}.nc"

# --- i4dvar.in 렌더 함수 ---
render_i4dvar_in() {
  (
    set -a 
    STDNAME="$stdname"
    NRMNAME="$nrmname"
    HSSNAME="${prefix_lres}_hss_${datenum}.nc"
    OBSNAME="$obsname"
    MODNAME="${prefix_lres}_mod_${datenum}"

    envsubst '$STDNAME,$NRMNAME,$HSSNAME,$OBSNAME,$MODNAME' \
      < "$i4dvar_template" > "$i4dvar_infile"
  ) || { echo "[ERR] envsubst 실패: i4dvar"; return 1; }

  grep -q  '\${[^}]\{1,\}}' "$i4dvar_infile" && {
    echo "[ERR] 미치환 변수 있음: $i4dvar_infile"; return 1; }
}

# --- da_ocean.in 렌더 함수 ---
render_da_in() {
  (
    set -a
    FWDNAME="${prefix_lres}_fwd_${datenum}.nc"
    RSTNAME="${prefix_lres}_rst_${datenum}.nc"
    HISNAME="${prefix_lres}_his_${datenum}.nc"
    AVGNAME="${prefix_lres}_avg_${datenum}.nc"
    TLMNAME="${prefix_lres}_tlm_${datenum}.nc"
    ADJNAME="${prefix_lres}_adj_${datenum}.nc"

    DSTART="${datenum}.0d0"

    GRDNAME="$grdname_lres"
    ININAME="$ininame_lres"
    ITLNAME="$itlname_lres"
    BRYNAME="$bryname_lres"

    IS4DVAR_PARAM="$i4dvar_infile"

    envsubst '$DSTART,$GRDNAME,$ININAME,$ITLNAME,$BRYNAME,$FWDNAME,$RSTNAME,$HISNAME,$AVGNAME,$TLMNAME,$ADJNAME,$IS4DVAR_PARAM' \
      < "$infile_template_lres" > "$infile_lres"
  ) || { echo "[ERR] envsubst 실패: da_ocean"; return 1; }

  grep -q  '\${[^}]\{1,\}}' "$infile_lres" && {
    echo "[ERR] 미치환 변수 있음: $infile_lres"; return 1; }
}

# --- nl_ocean.in 렌더 함수 ---
render_nl_in() {
  (
    set -a
    RSTNAME="${prefix_hres}_rst_${datenum}.nc"
    HISNAME="${prefix_hres}_his_${datenum}.nc"
    AVGNAME="${prefix_hres}_avg_${datenum}.nc"

    DSTART="${datenum}.0d0"

    GRDNAME="$grdname_hres"
    ININAME="$ininame_hres"
    BRYNAME="$bryname_hres"
    SSFNAME="$ssfname_hres"

    envsubst '$DSTART,$GRDNAME,$ININAME,$BRYNAME,$RSTNAME,$SSFNAME,$HISNAME,$AVGNAME' \
      < "$infile_template_hres" > "$infile_hres"
  ) || { echo "[ERR] envsubst 실패: nl_ocean"; return 1; }

  grep -q  '\${[^}]\{1,\}}' "$infile_hres" && {
    echo "[ERR] 미치환 변수 있음: $infile_hres"; return 1; }
}

while [ "$datenum" -le "$DAY_END" ]; do
  cycle=$((cycle+1))
  echo ">>>"
  echo ">>> Starting data assimilation cycle: $cycle (DAY=$datenum)"
  echo ">>>"

  cd "$app_dir/I4DVAR"
  rm -f ./*.nc 2>/dev/null || true

  itlname_lres=${prefix_lres}_itl_${datenum}.nc

  if [ "$datenum" -eq "$DAY_START" ]; then
    cp -fp "$first_guess_lres" "$ininame_lres"
  else
    cp -fp "$trunk/$ininame_lres" .
  fi

  # 월 자동 선택 (윤년 포함)
  mon_abbr=$(LC_ALL=C date -u -d "${TIME_REF} + ${datenum} days" +%b | tr '[:upper:]' '[:lower:]')
  stdname="${data_dir}/std/${prefix_lres}_std_i_${mon_abbr}_70.nc"
  [ -f "$stdname" ] || { echo "[ERR] STD 파일 없음: $stdname"; exit 1; }

  # ---- i4dvar.in 생성 (envsubst) ----
  render_i4dvar_in || exit 1

  # ---- da_ocean.in 생성 (envsubst) ----
  render_da_in     || exit 1


  # ==== Run incremental 4DVar algorithm ====
  echo ">>> Running I4DVAR algorithm, starting day: $datenum"
  echo ">>>"
  if [ -e da_log.prt ]; then
    /bin/rm -f da_log.prt
  fi
  
  mpirun -x MV2_ENABLE_AFFINITY=0 -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $romsM_lres $infile_lres > da_log.prt

  echo ">>> Done running I4DVAR, moving initial conditions to storage"
  echo ">>>"
  cp -f "$ininame_lres" "$trunk/$ininame_lres"
  # move DA initial to storage as a back up 
  mv -f "$ininame_lres" "${storage_lres}/${prefix_lres}_ini_DA_${datenum}.nc"
  mv -f "${prefix_lres}_mod_${datenum}.nc" "$storage_lres"
  mv -f "${prefix_lres}_fwd_*.nc" "$storage_lres"
  mv -f "${prefix_lres}_hss_*.nc" "$storage_lres"
  #  mv -f da_log.${DAY} $STORAGE
  mv -f "da_log.prt" "$storage_lres/da_log.${datenum}"


  # copy First guess from Forward run
  if [ $datenum -eq $DAY_START ]; then
    cp -p "${first_guess_hres}" "${trunk}/${ininame_hres}"
  fi

  "$CONDA_HOME/bin/conda" run -n romsforge --no-capture-output python ISL_L2H.py 

  # copy high resolution initial condition to STORAGE as a back up
  cp "${trunk}/${ininame_hres}" "$storage_hres/${prefix_hres}_ini_DA_lev36_${datenum}.nc"
  cp "${trunk}/${ininame_hres}" "$storage_hres/${prefix_hres}_ini_DA_incre_lev36_${datenum}.nc"
  # copy low resolution model increment as a back up
  cp "${trunk}/${prefix_lres}_ini_DA_incre.nc" "$storage_lres/${prefix_lres}_ini_DA_incre_${datenum}.nc"

  #---------------------------------------------------------------------

  # Run Nonlinear model initialized with 4DVAR estimated initial
  # conditions for the period of the assimilation time window. It
  # will compute the first guess for the next assimilation cycle
  #---------------------------------------------------------------------

  cd "$app_dir/Forward"

  # --- Create nl_ocean.in ---
  render_nl_in     || exit 1


  # Run nonlinear ROMS.

    echo ">>>"
    echo ">>> Running nonlinear model, starting day: $datenum"

    if [ -e nl_log.prt ]; then
      /bin/rm -f nl_log.prt
    fi

  mpirun -x MV2_ENABLE_AFFINITY=0 -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $romsM_hres $infile_hres > nl_log.prt

  # Move current nonlinear history and log files to storage.
  mv -f "${prefix_hres}_his_${datenum}*.nc" "${storage_hres}"
  mv -f "${prefix_hres}_avg_${datenum}*.nc" "${storage_hres}"
  mv -f "nl_log.prt" "$storage_hres/nl_log.${datenum}"

  # copy RST from high resolution model rst file to interpolation file
  # for coarse model initial condition for next DA cycle
  cp -f "$app_dir/Forward/${prefix_hres}_rst_${datenum}.nc" "$trunk/${prefix_hres}_RST_DA.nc"
  cp -f "$app_dir/Forward/${prefix_hres}_rst_${datenum}.nc" "$trunk/$ininame_hres"
  mv -f "${prefix_hres}_rst_${datenum}.nc" "${storage_hres}"
  #---------------------------------------------------------------------
  # Advance starting day for next assimilation cycle. Set new initial
  # conditions file name.
  #---------------------------------------------------------------------
  datenum=$((datenum + DAYSTEP))



  "$CONDA_HOME/bin/conda" run -n romsforge --no-capture-output python ISL_H2L.py 


  #---------------------------------------------------------------------
  # Move next cycle first guess (background state) to storage. It is
  # currently stored in the restart file.
  #---------------------------------------------------------------------
  cd "$app_dir/Forward"

  cp -f "$trunk/${prefix_lres}_RST_DA.nc" "${storage_lres}/${prefix_lres}_ini_${prefix_hres}_Fwd_${datenum}.nc"
  mv -f "$trunk/${prefix_lres}_RST_DA.nc" "$trunk/${prefix_lres}_ini_DA.nc"
  #---------------------------------------------------------------------
  # Move next cycle highresolution model first guess
  # (initial file) to input storage.
  #---------------------------------------------------------------------

  echo "  "
  echo ">>> Finished data assimilation cycle: $cycle"
  echo "  "
  echo "  "
done





























