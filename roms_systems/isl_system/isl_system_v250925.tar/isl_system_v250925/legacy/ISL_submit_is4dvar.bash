#!/bin/bash
#
# svn $Id: submit_is4dvar.bash 751 2015-01-07 22:56:36Z arango $
#######################################################################
# Copyright (c) 2002-2015 The ROMS/TOMS Group                         #
#   Licensed under a MIT/X style license                              #
#   See License_ROMS.txt                                              #
################################################## Hernan G. Arango ###
#                                                                     #
#  North Western Pacific 8km  experiment:                             #
#                                                                     #
#  This script is use to run ROMS incremental 4DVar algorithm in      #
#  sequential mode through several assimilation cycles. The user      #
#  needs to have the following directory structure:                   #
#                                                                     #
#    $MYROOT/                                                         #
#    $MYROOT/Data                                                     #
#    $MYROOT/Forward                                                  #
#    $MYROOT/IS4DVAR                                                  #
#    $MYROOT/OBS                                                      #
#                                                                     #
#  and storage directory:                                             #
#                                                                     #
#    $STORAGE                                                         #
#                                                                     #
#  To submit a job in the batch queue.  Use the following command     #
#  in MPI applications to avoid running on the head node NO_LOCAL:    #
#                                                                     #
#      batch now -f submit_is4dvar.bash                               #
#                                                                     #
#  To check batch use:                                                #
#                                                                     #
#      bbq                                                            #
#                                                                     #
#######################################################################

## PBS queue properties
#PBS -q workq
#PBS -l nodes=ust11:ppn=48,walltime=100:00:00
#PBS -V
#PBS -o .
#PBS -e .
#PBS -N ISL_control
JOBID=$PBS_JOBID

cd $PBS_O_WORKDIR
#PBS -N Check_WorkDir
echo "PBS_O_WORKDIR is $PBS_O_WORKDIR"

echo "  "
echo "**************************************************************"
echo "***     ROMS/TOMS Incremental, Strong Constraint 4DVar     ***"
echo "***  Master Execution Script: Sequential State Estimation  ***"
echo "**************************************************************"
echo "***"
#---------------------------------------------------------------------
#  Directories.
#---------------------------------------------------------------------

DATA=/data/share/DATA/ROMS_INPUTS
TRUNK=/home/shjo/ROMS/Applications/LTE_ECCO/ISL_ECCO_trunk

#  Set ROOT of the directory to run 4DVar.

MYROOT="/home/shjo/ROMS/ROMS_latest_v2B/project/ISL_70control"

#  Set ROMS/TOMS ROOT directory.

ROMS_ROOT="/home/shjo/ROMS/ROMS_latest_v2B"

#  Set storage directory for some of the relevant output NetCDF files.

STORAGE="/home/shjo/ROMS/Applications/LTE_ECCO/ISL_ECCO_L"
STORAGE_H="/home/shjo/ROMS/Applications/LTE_ECCO/ISL_ECCO_H"


mkdir $STORAGE $STORAGE_H
#---------------------------------------------------------------------
#  Application title and IO file prefix.
#---------------------------------------------------------------------

TITLE="ROMS/TOMS_svn751-NorthWestern Paicifc Forecast Model"

PREFIX="NWP4"
PREFIX_H="NWP12"

echo "***  $TITLE"
echo "***"
echo "   "

#---------------------------------------------------------------------
#  Input files.
#---------------------------------------------------------------------

# Set grid NetCDF file.
GRDname=${DATA}/grd/NWP4_grd_3_10m_LP.nc
GRDname_H=${DATA}/grd/NWP12_grd_NWP4.nc

# Set Open boundary conditions file, if any.
BRYname=${DATA}/bry/LTE/NWP4_bry_ECCO2_V2_FENNEL.nc
BRYname_H=${DATA}/bry/LTE/NWP12_bry_ECCO2_v2_36_FENNEL.nc


# Set starting sequential assimilation first guess.
FIRST_GUESS=${DATA}/ini/LTE/NWP4_ini_ECCO2_v2_M01_FENNEL.nc
FIRST_GUESS_H=${DATA}/ini/LTE/NWP12_ini_DA_lev36_v2_FENNEL.nc

# Set River forcing name
SSFNAME=${DATA}/river/roms_river_NWP12_2023_modi_time.nc

# Set background-error covariance normalization factor file
#NRMnameB=/disk2/DA_Fow_ecsy6/Data/NRM_v2/ecsy6_nrm_b.nc
NRMnameI=${DATA}/nrm/lte/NWP4_nrm_i_V2_40k_15m_5m.nc
#NRMnameF=/disk2/DA_Fow_ecsy6/Data/NRM_v2/ecsy6_nrm_f.nc

# Set observations file.
OBSname=${DATA}/obs/NWP4/NWP4_obs_sst_EN4_kodc_23_24.nc
#---------------------------------------------------------------------
#  Executables and standard input files
#---------------------------------------------------------------------

#  Set ROMS nonlinear and data assimilation executables.

NL_ROMS="nl_NWP12_oceanM"
DA_ROMS="da_NWP4_oceanM"

#  Set ROMS nonlinear and data assimilation standard input scripts.

NL_TEMPLATE=${MYROOT}/nl_ocean.tmp
DA_TEMPLATE=${MYROOT}/da_ocean.tmp

NL_STDINP=nl_ocean_${PREFIX_H}.in
DA_STDINP=da_ocean_${PREFIX}.in

#  Set ROMS Metatada variables file.

VARINFO=${MYROOT}/Data/varinfo.dat

#  Set 4DVar input script.

IS4DVAR_TEMPLATE=s4dvar_ecco.in

IS4DVAR_PARAM=i4dvar.in

#  Set string manipulations perl script.
#SUBSTITUTE=/home/jhlee/model/ROMS_latest/ROMS/Bin/substitute
SUBSTITUTE=/home/jhlee/model/ROMS_latest/ROMS/Bin/substitute
#---------------------------------------------------------------------
#  Time window to consider.
#---------------------------------------------------------------------

#  Set starting and ending year day of the sequential data assimilation.
#  (Reference time: days since 1993-01-01 00:00:00)

#STR_DAY=8433              # Jan. 01, 2011 00:00:00 UTC/GMT
#END_DAY=8497

STR_DAY=8401              # Jan. 01, 2011 00:00:00 UTC/GMT
END_DAY=8523



#END_DAY=6577

#  Set data assimilation cycle time window (days).

DayStep=8

#---------------------------------------------------------------------
#  Set few Parameters.
#---------------------------------------------------------------------

#  Set model parallel partition.

NtileI=8
NtileJ=6

#  Set number of parallel nodes to use, NCPUS = NtileI * NtileJ.

NCPUS=48

#  Set number of outer and inner loops.

Nouter=1
Ninner=12

#  Set number of timesteps to write RESTART file.  This is VERY
#  Important since we are using the restart file of the nonlinear
#  model run as the first guess fot the next assimilation cycle.
#  It MUST be equal to NTIMES.

#NRST=1440
#NRST_H=1440 # 2

NRST=1440
#NRST=720
NRST_H=3456 # 8
# NRST_H=1152 # 8

#  Set enviromental variables to avoid running in the head node.

NO_LOCAL=1
EXCLUDE=10
export NO_LOCAL EXCLUDE

######################################################################
#  Start sequential data assimilation
######################################################################

cycle=0

DAY=$STR_DAY

#  Set starting initial conditions file name.

#INIname=${PREFIX}_ini_${DAY}.nc
INIname=${PREFIX}_ini_DA.nc
INIname_H=NWP12_ini_DA_lev36.nc
ITLname=${PREFIX}_itl_${DAY}.nc

while [ $DAY -le $END_DAY ]; do
#echo $END_DAY
  let "cycle+=1"

  echo ">>>"
  echo ">>> Starting data assimilation cycle: $cycle"
  echo ">>>"

#---------------------------------------------------------------------
# Run 4DVar Algorithm.
#---------------------------------------------------------------------

  cd $MYROOT/I4DVAR

# Clean directory by removing all existing NetCDF files.

  if [ -e $ITLname ]; then
    /bin/rm -f $MYROOT/I4DVAR/*.nc
  fi
  ITLname=${PREFIX}_itl_${DAY}.nc

# Set backgound (first guess) state file.

  if [ $DAY -eq $STR_DAY ]; then
    cp -p ${FIRST_GUESS} $INIname
  else
    cp -p $TRUNK/$INIname .
    #cp -p ${STORAGE}/$INIname .
  fi

# Set tangent linear model initial conditions file.

#  cp -p ${MYROOT}/Data/${PREFIX}_ini_zero.nc $ITLname

# Get a clean copy of the observation file.  This is really
# important since this file is modified to compute the
# fractional vertical position of the observations when
# they are specified as depth in meter (negative values).

  # cp -p ${MYROOT}/OBS/$OBSname .
  cp -p $OBSname .
# Set background-error covariance standard deviations file.
  YY=`expr $DAY \/ 365`
  YYMM=$(echo "$DAY 365" | awk '{print $1/$2}')
  REM=$(echo "$YYMM $YY 10000" | awk '{print ($1-$2)*$3}')
#  REM=`expr $REM \/ 1`
  if [ $REM -le 830  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_jan_70.nc
  elif [ $REM -le 1660 ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_feb_70.nc
  elif [ $REM -le 2500  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_mar_70.nc
  elif [ $REM -lt 3330  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_apr_70.nc
  elif [ $REM -lt 4160  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_may_70.nc
  elif [ $REM -lt 5000  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_jun_70.nc
  elif [ $REM -lt 5830  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_jul_70.nc
  elif [ $REM -lt 6660  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_aug_70.nc
  elif [ $REM -lt 7500  ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_sep_70.nc
  elif [ $REM -lt 8330 ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_oct_70.nc
  elif [ $REM -lt 9160 ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_nov_70.nc
  elif [ $REM -lt 10000 ]; then
      STDnameI=${DATA}/std/std_NWP4/70/NWP4_std_i_dec_70.nc
  else
      STDnameI=${DATA}/std/std_NWP4/NWP4_std_i_jan.nc
  fi
# Modify 4DVar template input script and specify above files.

  if [ -e $IS4DVAR_PARAM ]; then
    /bin/rm $IS4DVAR_PARAM
  fi
  cp $IS4DVAR_TEMPLATE $IS4DVAR_PARAM

  $SUBSTITUTE $IS4DVAR_PARAM ocean_std_i.nc $STDnameI
#  $SUBSTITUTE $IS4DVAR_PARAM ocean_std_b.nc $STDnameB
#  $SUBSTITUTE $IS4DVAR_PARAM ocean_std_f.nc $STDnameF
  $SUBSTITUTE $IS4DVAR_PARAM ocean_nrm_i.nc $NRMnameI
#  $SUBSTITUTE $IS4DVAR_PARAM ocean_nrm_b.nc $NRMnameB
#  $SUBSTITUTE $IS4DVAR_PARAM ocean_nrm_f.nc $NRMnameF
  $SUBSTITUTE $IS4DVAR_PARAM ocean_hss.nc ${PREFIX}_hss_${DAY}.nc
  $SUBSTITUTE $IS4DVAR_PARAM ocean_obs.nc $OBSname
  $SUBSTITUTE $IS4DVAR_PARAM ocean_mod.nc ${PREFIX}_mod_${DAY}.nc

# Modify 4DVar ROMS standard input script.

  if [ -e $DA_STDINP ]; then
    /bin/rm $DA_STDINP
  fi
  cp $DA_TEMPLATE $DA_STDINP

  $SUBSTITUTE $DA_STDINP MyTITLE $TITLE
#  $SUBSTITUTE $DA_STDINP varinfo.dat $VARINFO
  $SUBSTITUTE $DA_STDINP MyNtileI $NtileI
  $SUBSTITUTE $DA_STDINP MyNtileJ $NtileJ
  $SUBSTITUTE $DA_STDINP MyNouter $Nouter
  $SUBSTITUTE $DA_STDINP MyNinner $Ninner
  $SUBSTITUTE $DA_STDINP MyNRST $NRST
  $SUBSTITUTE $DA_STDINP MyDSTART ${DAY}.0d0

  $SUBSTITUTE $DA_STDINP ocean_grd.nc $GRDname
  $SUBSTITUTE $DA_STDINP ocean_ini.nc $INIname
  $SUBSTITUTE $DA_STDINP ocean_itl.nc $ITLname
  $SUBSTITUTE $DA_STDINP ocean_bry.nc $BRYname
  $SUBSTITUTE $DA_STDINP ocean_fwd.nc ${PREFIX}_fwd_${DAY}.nc

  $SUBSTITUTE $DA_STDINP ocean_rst.nc ${PREFIX}_rst_${DAY}.nc
  $SUBSTITUTE $DA_STDINP ocean_his.nc ${PREFIX}_his_${DAY}.nc
  $SUBSTITUTE $DA_STDINP ocean_avg.nc ${PREFIX}_avg_${DAY}.nc
  $SUBSTITUTE $DA_STDINP ocean_tlm.nc ${PREFIX}_tlm_${DAY}.nc
  $SUBSTITUTE $DA_STDINP ocean_adj.nc ${PREFIX}_adj_${DAY}.nc
  $SUBSTITUTE $DA_STDINP s4dvar.in $IS4DVAR_PARAM



# Run incremental 4DVar algorithm.

  echo ">>> Running I4DVAR algorithm, starting day: $DAY"
  echo ">>>"

  if [ -e da_log.prt ]; then
    /bin/rm -f da_log.prt
  fi
#  echo NCPUS   DA_ROMS   DA_STDINP   DAY
 echo $NCPUS   $DA_ROMS   $DA_STDINP  $DAY
# mpirun -np $NCPUS $DA_ROMS $DA_STDINP > da_log.prt
# mpirun -genv MV2_ENABLE_AFFINITY 0 -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $DA_ROMS $DA_STDINP > da_log.prt
# OpenMPI
mpirun -x MV2_ENABLE_AFFINITY=0 -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $DA_ROMS $DA_STDINP > da_log.prt


# Move estimated initial conditions, misfit, and log files to storage.

  echo ">>> Done running I4DVAR, moving initial conditions to storage"
  echo ">>>"
# give initial condition as default name for interpolating higher 
# resolution
# Copy initial file to Data for interpolation to high resolution grd
  # cp -f $INIname $MYROOT/Data/$INIname
  cp -f $INIname $TRUNK/$INIname
# move DA initial to storage as a back up 
  mv -f $INIname ${STORAGE}/${PREFIX}_ini_DA_${DAY}.nc
  mv -f ${PREFIX}_mod_${DAY}.nc $STORAGE
  mv -f ${PREFIX}_fwd_*.nc $STORAGE
  mv -f ${PREFIX}_hss_*.nc $STORAGE
#  mv -f da_log.${DAY} $STORAGE
  mv -f da_log.prt $STORAGE/da_log.${DAY}
##--------------------------------------------------------------------
export MATLAB_DIR=/usr/local/MATLAB/R2024a/bin
#wdr=/home/jhlee/Matlab_tools/rutgers_mat/initial
wdr=/home/shjo/ROMS/ROMS_latest_v2B/project/ISL_70control/matlab_codes
# Interpolate coarse grid initial to higher resolution 
# initial condition for forward model (Hiresolution name is same as INIname_H)
##--------------------------------------------------------------------
# copy First guess from Forward run
  if [ $DAY -eq $STR_DAY ]; then
    # cp -p ${FIRST_GUESS_H} ${MYROOT}/Data_NWP12/NWP12_ini_DA_lev36.nc
    cp -p ${FIRST_GUESS_H} ${TRUNK}/${INIname_H}
  fi
# get increment
echo ">>> Start matlab ... <<<"
# nohup $MATLAB_DIR/matlab -nosplash -nojvm < $wdr/calc_increment.m
nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/calc_increment.m'); exit" > ./matlab1.log 2>&1

echo ">>> End matlab 01 <<<"
## this function needs to be used in newer thatn 2012 version of matlab
# interpolate increment to high resolution
#nohup $MATLAB_DIR/matlab -nosplash -nojvm < $wdr/d_roms2roms_NWP4_NWP12newgrd_incre_lev36.m
#nohup $MATLAB_DIR/matlab -nosplash -nojvm < $wdr/interpolate_increment_L2H.m

nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/interpolate_increment_L2H.m'); exit" > ./matlab2.log 2>&1

echo ">>> End matlab 02 <<<"
# add increment to high resolution model initial condition
#nohup $MATLAB_DIR/matlab -nosplash -nojvm < $wdr/joint_increment.m
nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/joint_increment.m'); exit" > ./matlab3.log 2>&1

echo ">>> End matlab 03 <<<"

# copy high resolution initial condition to STORAGE as a back up
cp ${TRUNK}/${INIname_H} $STORAGE_H/NWP12_ini_DA_lev36_${DAY}.nc
cp ${TRUNK}/${INIname_H} $STORAGE_H/NWP12_ini_DA_incre_lev36_${DAY}.nc
# copy low resolution model increment as a back up
cp ${TRUNK}/NWP4_ini_DA_incre.nc $STORAGE/NWP4_ini_DA_incre_${DAY}.nc

#---------------------------------------------------------------------

# Run Nonlinear model initialized with 4DVAR estimated initial
# conditions for the period of the assimilation time window. It
# will compute the first guess for the next assimilation cycle
#---------------------------------------------------------------------

  cd $MYROOT/Forward

# Create ROMS standard input script from template.

  if [ -e $NL_STDINP ]; then
    /bin/rm $NL_STDINP
  fi
  cp $NL_TEMPLATE $NL_STDINP

  RSTname_H=${PREFIX_H}_rst_${DAY}.nc

  $SUBSTITUTE $NL_STDINP MyTITLE $TITLE
  $SUBSTITUTE $NL_STDINP MyNtileI $NtileI
  $SUBSTITUTE $NL_STDINP MyNtileJ $NtileJ
  $SUBSTITUTE $NL_STDINP MyNRST $NRST_H
  $SUBSTITUTE $NL_STDINP MyDSTART ${DAY}.0d0

  $SUBSTITUTE $NL_STDINP ocean_grd.nc $GRDname_H
  $SUBSTITUTE $NL_STDINP ocean_ini.nc $TRUNK/$INIname_H
  $SUBSTITUTE $NL_STDINP ocean_bry.nc $BRYname_H
  $SUBSTITUTE $NL_STDINP ocean_rivers.nc $SSFNAME

  $SUBSTITUTE $NL_STDINP ocean_rst.nc $RSTname_H
  $SUBSTITUTE $NL_STDINP ocean_his.nc ${PREFIX_H}_his_${DAY}.nc
  $SUBSTITUTE $NL_STDINP ocean_avg.nc ${PREFIX_H}_avg_${DAY}.nc

# Run nonlinear ROMS.

  echo ">>>"
  echo ">>> Running nonlinear model, starting day: $DAY"

  if [ -e nl_log.prt ]; then
    /bin/rm -f nl_log.prt
  fi

#  echo $NCPUS   $NL_ROMS   $NL_STDINP  $DAY
 # mpirun -np $NCPUS $NL_ROMS $NL_STDINP > nl_log.prt

# mpirun -genv MV2_ENABLE_AFFINITY 0 -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $NL_ROMS $NL_STDINP > nl_log.prt

# OpenMPI
mpirun -x MV2_ENABLE_AFFINITY=0 -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $NL_ROMS $NL_STDINP > nl_log.prt

# Move current nonlinear history and log files to storage.

   mv -f ${PREFIX_H}_his_${DAY}*.nc ${STORAGE_H}
   mv -f ${PREFIX_H}_avg_${DAY}*.nc ${STORAGE_H}
   mv -f nl_log.prt $STORAGE_H/nl_log.${DAY}

#---------------------------------------------------------------------
# Advance starting day for next assimilation cycle. Set new initial
# conditions file name.
#---------------------------------------------------------------------
  let "DAY+=DayStep"
#  INIname_H=${PREFIX_H}_ini_${DAY}.nc
# copy RST from high resolution model rst file to interpolation file
# for coarse model initial condition for next DA cycle
  #cp -f $MYROOT/Forward/$RSTname_H $MYROOT/Data_NWP12/NWP12_RST_DA_lev36.nc
  cp -f $MYROOT/Forward/$RSTname_H $TRUNK/NWP12_RST_DA_lev36.nc
#---------------------------------------------------------------------
# interpolate high resolution Forward model rst file to 
# coarse model initial condition for following DA cycle
#  nohup $MATLAB_DIR/matlab -nosplash -nojvm < $wdr/d_roms2roms_newgrdNWP12_NWP4_lev36_sponge.m >> log_NWP12.out
#nohup $MATLAB_DIR/matlab -nosplash -nojvm < $wdr/interpolate_increment_H2L.m >> log_NWP12.out

nohup $MATLAB_DIR/matlab -nosplash -nojvm -r "run('$wdr/interpolate_increment_H2L.m'); exit" > ./matlab4.log 2>&1
#---------------------------------------------------------------------
#---------------------------------------------------------------------
# Move next cycle first guess (background state) to storage. It is
# currently stored in the restart file.
#---------------------------------------------------------------------
  cd $MYROOT/Forward
  # cp -f $MYROOT/Data/NWP4_RST_DA.nc ${STORAGE}/${PREFIX}_ini_NWP12_Fwd_${DAY}.nc
  # mv -f $MYROOT/Data/NWP4_RST_DA.nc $MYROOT/Data/NWP4_ini_DA.nc
  cp -f $TRUNK/NWP4_RST_DA.nc ${STORAGE}/${PREFIX}_ini_NWP12_Fwd_${DAY}.nc
  mv -f $TRUNK/NWP4_RST_DA.nc $TRUNK/NWP4_ini_DA.nc
#---------------------------------------------------------------------
# Move next cycle highresolution model first guess
# (initial file) to input storage.
#---------------------------------------------------------------------
  #cp -f $MYROOT/Forward/$RSTname_H $TRUNK/NWP12_ini_DA_lev36.nc
  cp -f $MYROOT/Forward/$RSTname_H $TRUNK/$INIname_H
  mv -f $RSTname_H ${STORAGE_H}
  echo "  "
  echo ">>> Finished data assimilation cycle: $cycle"
  echo "  "
  echo "  "
done
#cp -f ${STORAGE}/${INIname} /home/jhlee/model/ROMS_latest/project/DA_Fow_NWP4/Data/${INIname}
