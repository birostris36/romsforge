clear;
%% This routine will be run by old matlab (i.e 2008)
run('/home/shjo/ROMS/romsforge/py/matlab_codes/LSI_tools/startup.m');
% run('/home/jhlee/Matlab_tools/new.m');
disp('!!! start')
TRUNK = '/data/shjo/applications/nifs01_test/storage/test_isl_matlab/trunk/';

Inpa = [TRUNK 'wnp25km_ini.nc'];
% f_path1='/disk11/NWP4_DA_T1/';
% Inpa = [f_path1 'NWP4_ini_DA_6574.nc'];
% Inpa = [f_path2 'NWP4_ini_DA_6577.nc'];

WRITE=1;

Rec_post=1;
Rec_pri=2;
FillValue=nan;

o_time=nc_read(Inpa,'ocean_time',Rec_pri);
zetab=nc_read(Inpa,'zeta',Rec_pri,FillValue);
u2b=nc_read(Inpa,'ubar',Rec_pri,FillValue);
v2b=nc_read(Inpa,'vbar',Rec_pri,FillValue);
ub=nc_read(Inpa,'u',Rec_pri,FillValue);
vb=nc_read(Inpa,'v',Rec_pri,FillValue);
tempb=nc_read(Inpa,'temp',Rec_pri,FillValue);
saltb=nc_read(Inpa,'salt',Rec_pri,FillValue);


zetaa=nc_read(Inpa,'zeta',Rec_post,FillValue);
u2a=nc_read(Inpa,'ubar',Rec_post,FillValue);
v2a=nc_read(Inpa,'vbar',Rec_post,FillValue);
ua=nc_read(Inpa,'u',Rec_post,FillValue);
va=nc_read(Inpa,'v',Rec_post,FillValue);
tempa=nc_read(Inpa,'temp',Rec_post,FillValue);
salta=nc_read(Inpa,'salt',Rec_post,FillValue);

% Read in posterior circulation initial conditions (Rec=1) and
% replace land/sea mask values with NaNs.

% Compute I4D-Var increments by substracting prior from
% posterior initial conditions.
disp('calc diff')
diffz=zetaa-zetab;
diffu2=u2a-u2b;
diffv2=v2a-v2b;
diffu=ua-ub;
diffv=va-vb;
difft=tempa-tempb;
diffs=salta-saltb;
% reduce the increment by half
% because the increment of higher resolution become lager as time went by
factor=1;
diffz=diffz./factor;
diffu2=diffu2./factor;
diffv2=diffv2./factor;
diffu=diffu./factor;
diffv=diffv./factor;
difft=difft./factor;
diffs=diffs./factor;
disp('write dif')
if WRITE,
    % f_path='/disk1/model/ROMS_latest/project/DA_Fow_NWP4_lev36_sponge_aqua/Data/';
    org_file=['/data/shjo/applications/nifs01_test/storage/data/NWP4_ini_3_10m_LP_standard.nc'];
    %% copy alawys increment file which has one time dimension
    Inpa = [TRUNK 'NWP4_ini_DA_incre.nc'];
    unix(['cp ' org_file ' ' Inpa]);
    
%     field = 'ocean_time';
%     o_time =6577*86400;
%   [err.(field)] = nc_write(Inpa, field, o_time, Rec_post);
%     nc=netcdf(Inpa,'w');
%     nc{'ocean_time'}(1)=6577*86400;
%     close(nc); clear nc
    nc_write(Inpa,'ocean_time',o_time,Rec_post);
    nc_write(Inpa,'zeta',diffz,Rec_post);
    nc_write(Inpa,'ubar',diffu2,Rec_post);
    nc_write(Inpa,'vbar',diffv2,Rec_post);
    nc_write(Inpa,'u',diffu,Rec_post);
    nc_write(Inpa,'v',diffv,Rec_post);
    nc_write(Inpa,'temp',difft,Rec_post);
    nc_write(Inpa,'salt',diffs,Rec_post);
end
disp('increment was calculated in low resolution model');
disp('!!! SHJO: increment was calculated in low resolution model');
% 
% diffz1=flipud(diffz);
% diffz1=fliplr(diffz1);
% clf
% % diff_val=squeeze(tempa(:,:,20));
% diff_val=(squeeze(difft(:,:,20)))';
% pcolor(diff_val);
% shading flat
% colorbar
% caxis([-5 5])
% caxis([-2 32])
% the result of this program will be used in interpolation of higher model

