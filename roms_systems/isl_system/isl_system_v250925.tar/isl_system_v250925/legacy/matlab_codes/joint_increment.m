clear;
%% This routine will be run by old matlab (i.e R2008)
run('/home/jhlee/Matlab_tools/rutgers_mat/startup.m');

% f_path = '/home/jhlee/model/ROMS_latest/project/DA_Fow_NWP4_lev36_sponge_aqua/Data_NWP12/';
% TRUNK = '/data/shjo/applications/nifs01w3/trunk/';
TRUNK = '/data/shjo/applications/nifs01_test/storage/test_isl_matlab/trunk/';

Inpa = [TRUNK, 'wnp8km_ini.nc'];
Inpb = [TRUNK, 'NWP12_ini_DA_incre_lev36.nc'];
%% Inpb is the result of interpolation from lower resolution increment
%% which is updated from 4DVAR
%% Inpa is the result of high resolution model from nonlinear model

Rec=1;
FillValue=NaN;

o_time=nc_read(Inpb,'ocean_time');
zetab=nc_read(Inpb,'zeta',Rec,FillValue);
u2b=nc_read(Inpb,'ubar',Rec,FillValue);
v2b=nc_read(Inpb,'vbar',Rec,FillValue);
ub=nc_read(Inpb,'u',Rec,FillValue);
vb=nc_read(Inpb,'v',Rec,FillValue);
tempb=nc_read(Inpb,'temp',Rec,FillValue);
saltb=nc_read(Inpb,'salt',Rec,FillValue);



zetaa=nc_read(Inpa,'zeta',Rec,FillValue);
u2a=nc_read(Inpa,'ubar',Rec,FillValue);
v2a=nc_read(Inpa,'vbar',Rec,FillValue);
ua=nc_read(Inpa,'u',Rec,FillValue);
va=nc_read(Inpa,'v',Rec,FillValue);
tempa=nc_read(Inpa,'temp',Rec,FillValue);
salta=nc_read(Inpa,'salt',Rec,FillValue);


diffz=zetaa+zetab;
diffu2=u2a+u2b;
diffv2=v2a+v2b;
diffu=ua+ub;
diffv=va+vb;
difft=tempa+tempb;
diffs=salta+saltb;

nc_write(Inpa,'ocean_time',o_time(1),Rec);
nc_write(Inpa,'zeta',diffz,Rec);
nc_write(Inpa,'ubar',diffu2,Rec);
nc_write(Inpa,'vbar',diffv2,Rec);
nc_write(Inpa,'u',diffu,Rec);
nc_write(Inpa,'v',diffv,Rec);
nc_write(Inpa,'temp',difft,Rec);
nc_write(Inpa,'salt',diffs,Rec);

disp('done add increment for high resolution');

disp('!!! shjo: done add increment for high resolution !!!');

% diffz1=flipud(diffz);
% diffz1=fliplr(diffz1);
% clf
% % diff_val=squeeze(tempa(:,:,20));
% diff_val=(squeeze(difft(:,:,20)))';
% pcolor(diff_val);
% shading flat
% colorbar
% caxis([-5 5])
% caxis([-2 32])
