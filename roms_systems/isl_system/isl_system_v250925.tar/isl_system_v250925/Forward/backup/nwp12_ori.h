/*
** svn $Id: pete_NWP6.h 139 2008-01-10 00:17:29Z arango $
*******************************************************************************
** Copyright (c) 2002-2008 The ROMS/TOMS Group                               **
**   Licensed under a MIT/X style license                                    **
**   See License_ROMS.txt                                                    **
*******************************************************************************
**
** Options for Norh West Pacific case.
**
** Application flag:   ecsy10 from NWP4_level 10
** Input script:       ecsy10.in
*/

#undef WET_DRY
#define UV_ADV
#define UV_QDRAG
#define UV_COR
#define UV_VIS2 
#undef UV_SMAGORINSKY
#define TS_DIF2 
#undef TS_SMAGORINSKY
#define MIX_S_UV
#define MIX_GEO_TS
#define DJ_GRADPS
#define TS_U3HADVECTION
#define NONLIN_EOS
#define SALINITY
#define SOLVE3D
#define MASKING
#define SPLINES

#undef QCORRECTION  /*net heat flux correction */
#define SCORRECTION  /*freshwater flux correction*/
#define SOLAR_SOURCE /*solar radiation source term*/
#undef DIURNAL_SRFLUX /*mdulate input shortwave with diurnal cycle*/
#undef SRELAXATION   /*salinity relaxation as a freshwater flux*/
/*BULK FLUX*/

#define BULK_FLUXES
#define LONGWAVE_OUT
#undef EMINUSP
#undef ANA_CLOUD
#undef ANA_RAIN

#define CURVGRID
#undef UV_PSOURCE /*river flux*/
#undef TS_PSOURCE /*river flux*/
#undef ANA_PSOURCE
#undef ANA_SMFLUX
#undef DIAGNOSTICS_TS
#undef DIAGNOSTICS_UV
#undef T_PASSIVE
#undef ANA_PASSIVE

/* output*/

#define AVERAGES_AKV
#define AVERAGES_AKT
#define AVERAGES_AKS
#define AVERAGES_FLUXES

/*#define AVERAGES_DETIDE*/
#define AVERAGES
#undef STATIONS
#undef FLOATS
#undef PERFECT_RESTART

/* option for vertical mixing */
#define GLS_MIXING
#undef  MY25_MIXING
#undef  LMD_MIXING

#ifdef GLS_MIXING
# define N2S2_HORAVG
# define KANTHA_CLAYSON
#endif

#ifdef MY25_MIXING
# define N2S2_HORAVG
# define KANTHA_CLAYSON
#endif

#ifdef LMD_MIXING
# define LMD_RIMIX
# define LMD_CONVEC
# undef LMD_DDMIX
# define LMD_SKPP
# undef LMD_BKPP
# define LMD_NONLOCAL
#endif
/* set bottom boundary value zero*/
#define ANA_BSFLUX
#define ANA_BTFLUX

#define ANA_SPONGE

#define BIO_FENNEL
#undef ANA_BIOLOGY
#ifdef BIO_FENNEL
# define CARBON
# define DENITRIFICATION
# define BIO_SEDIMENT
# undef DIAGNOSTICS_BIO
#endif

#define ANA_SPFLUX
#define ANA_BPFLUX

#define UV_TIDES
#define SSH_TIDES
#define ADD_M2OBC
#define ADD_FSOBC
#undef RAMP_TIDES

