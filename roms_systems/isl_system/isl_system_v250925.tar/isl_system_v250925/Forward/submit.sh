#!/bin/bash
#PBS -N physics_only
#PBS -q workq
#PBS -l nodes=ust11:ppn=48
#PBS -l walltime=100:00:00
#PBS -V

cd $PBS_O_WORKDIR

export MV2_ENABLE_AFFINITY=0


# 총 프로세스 수 계산
NP=$(wc -l < $PBS_NODEFILE)

# 실행
mpirun -machinefile $PBS_NODEFILE -np $NP ./nl_NWP12_oceanM nl_ocean_NWP12.in > phys_only.log 2>&1

#mpirun -machinefile $PBS_NODEFILE -np `cat $PBS_NODEFILE | wc -l` $DA_ROMS $DA_STDINP > da_log.prt

