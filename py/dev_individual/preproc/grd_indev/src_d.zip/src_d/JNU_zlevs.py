# -*- coding: utf-8 -*-
"""
Created on Sun Jan 22 17:22:34 2023

@author: birostris
@email : birostris36@gmail.com

Name : 
Reference :
Description :
"""
import numpy as np

def zlevs(Vtransform, Vstretching,theta_s, theta_b, hc, N,igrid, h, zeta, report):
    from copy import deepcopy
    
    Np=N+1;
    Lp,Mp=h.shape
    L=Lp-1;
    M=Mp-1;
    
    hmin=np.min(h);
    hmax=np.max(h);

    # Compute vertical stretching function, C(k):

    if igrid==5:
        kgrid=1
        s,C=stretching(Vstretching, theta_s, theta_b, Np, kgrid)
    else:
        kgrid=0
        s,C=stretching(Vstretching, theta_s, theta_b, N, kgrid)

    #  Average bathymetry and free-surface at requested C-grid type.

    if igrid==1:
        hr=deepcopy(h)
        zetar=deepcopy(zeta)
    elif igrid==2:
        hp=0.25*(h[:L,:M]+h[1:Lp,:M]+h[:L,1:Mp]+h[1:Lp,1:Mp])
        zetap=0.25*(zeta[:L,:M]+zeta[1:Lp,:M]+zeta[:L,1:Mp]+zeta[1:Lp,1:Mp])
    elif igrid==3:
        hu=0.5*(h[:L,:Mp]+h[1:Lp,:Mp])
        zetau=0.5*(zeta[:L,:Mp]+zeta[1:Lp,:Mp])
    elif igrid==4:
        hv=0.5*(hp[:Lp,:M]+h[:Lp,1:Mp])
        zetav=0.5*(zeta[:Lp,:M]+zeta[:Lp,1:Mp])        
    elif igrid==5:
        hr=deepcopy(h)
        zetar=deepcopy(zeta)


    # Compute depths (m) at requested C-grid location.
    if Vtransform==1:
        if igrid==1:
            z=np.zeros([zetar.shape[0],zetar.shape[-1],N])
            for k in range(N):
                z0=(s[k]-C[k])*hc+C[k]*hr
                z[:,:,k]=z0+zetar*(1+z0/hr)
        elif igrid==2:
            z=np.zeros([zetap.shape[0],zetap.shape[-1],N])
            for k in range(N):
                z0=(s[k]-C[k])*hc+C[k]*hp
                z[:,:,k]=z0+zetap*(1+z0/hp)
        elif igrid==3:
            z=np.zeros([zetau.shape[0],zetau.shape[-1],N])
            for k in range(N):
                z0=(s[k]-C[k])*hc+C[k]*hu
                z[:,:,k]=z0+zetau*(1+z0/hu)
        elif igrid==4:
            z=np.zeros([zetav.shape[0],zetav.shape[-1],N])
            for k in range(N):
                z0=(s[k]-C[k])*hc+C[k]*hv
                z[:,:,k]=z0+zetav*(1+z0/hv)
        elif igrid==5:
            z=np.zeros([zetar.shape[0],zetar.shape[-1],Np])
            z[:,:,0]=-hr
            for k in range(1,Np):
                z0=(s[k]-C[k])*hc+C[k]*hr
                z[:,:,k]=z0+zetar*(1+z0/hr)
    
    elif Vtransform==2:
        if igrid==1:
            z=np.zeros([zetar.shape[0],zetar.shape[-1],N])
            for k in range(N):
                z0=(hc*s[k]+C[k]*hr)/(hc+hr)
                z[:,:,k]=zetar+(zeta+hr)*z0
        elif igrid==2:
            z=np.zeros([zetap.shape[0],zetap.shape[-1],N])
            for k in range(N):
                z0=(hc*s[k]+C[k]*hp)/(hc+hp)
                z[:,:,k]=zetap+(zetap+hp)*z0
        elif igrid==3:
            z=np.zeros([zetau.shape[0],zetau.shape[-1],N])
            for k in range(N):
                z0=(hc*s[k]+C[k]*hu)/(hc+hu)
                z[:,:,k]=zetau+(zetau+hu)*z0
        elif igrid==4:
            z=np.zeros([zetav.shape[0],zetav.shape[-1],N])
            for k in range(N):
                z0=(hc*s[k]+C[k]*hv)/(hc+hv)
                z[:,:,k]=zetav+(zetav+hv)*z0
        elif igrid==5:
            z=np.zeros([zetar.shape[0],zetar.shape[-1],Np])
            for k in range(1,Np):
               z0=(hc*s[k]+C[k]*hr)/(hc+hr)
               z[:,:,k]=zetar+(zetar+hr)*z0
    z=np.transpose(z,[2,0,1])
    
    return z
    