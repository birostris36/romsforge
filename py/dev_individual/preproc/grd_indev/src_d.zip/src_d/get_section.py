# -*- coding: utf-8 -*-
"""
Created on Thu Feb  2 16:24:25 2023

@author: birostris
@email : birostris36@gmail.com

Name : 
Reference :
Description :
"""

PKG_path = 'D:/Working_hub/OneDrive/base142/Factory/MantaROMS/src_d/'
import sys 
sys.path.append(PKG_path)
import JNUROMS as jr
from JNU_create import create_ini
import numpy as np
from netCDF4 import Dataset,MFDataset,date2num,num2date
import os
from scipy.interpolate import griddata
import datetime as dt
from tqdm import tqdm
import matplotlib.pyplot as plt

S_coor_data_path = 'D:/Working_hub/OneDrive/base142/Factory/MantaROMS/Test_nc/Ini_soda.nc'
S_coor_Grid_path = 'D:/Working_hub/OneDrive/base142/Warehouse01/Grd_v2_10d_24S.nc'

lon_rng,lat_rng=[0,360],[-60]

lon_rng,lat_rng=[70],[-70,-24]


ncD=Dataset(S_coor_data_path)
ncG=Dataset(S_coor_Grid_path)


X,Z,VAR=jr.get_section(ncG,ncD,'temp',lon_rng,lat_rng,tindx=0)


from scipy import io
from matplotlib.colors import ListedColormap,LinearSegmentedColormap
NN=13
cmap_dir='C:/Users/shjo9/Desktop/Codes/Model_results_69/Verticals/SourceCodes/'
Colorbars=np.load(cmap_dir+'Spectral.mat')
cmap_sst=ListedColormap(Colorbars)


plt.pcolor(X,Z,VAR,cmap=cmap_sst)
plt.clim(-1,27)
plt.colorbar()



plt.pcolormesh(VAR,cmap=cmap_sst)
plt.clim(-1,27)
plt.colorbar()














