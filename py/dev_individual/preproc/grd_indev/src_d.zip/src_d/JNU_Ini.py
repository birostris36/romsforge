# -*- coding: utf-8 -*-
"""
Created on Sat Jan 21 15:47:04 2023

@author: birostris
@email : birostris36@gmail.com

Name : 
Reference :
Description :
"""

import numpy as np




def stretching(Vstretching,theta_s,theta_b,Layer_N,kgrid=1):
    
    # Vstretching=MyVar['Vstretching']
    # theta_s=MyVar['Theta_s']
    # theta_b=MyVar['Theta_b']
    # N=MyVar['Layer_N']    
    Np=Layer_N+1
    if Vstretching==1:
        ds=1/Layer_N
        if kgrid==1:
            nlev=Np
            lev=np.arange(Layer_N+1)
            s=(lev-Layer_N)*ds
        else:
            Nlev=Layer_N
            lev=np.arange(1,Layer_N+1)-.5
            s=(lev-Layer_N)*ds
        
        if theta_s>0:
            Ptheta=np.sinh(theta_s*s)/np.sinh(theta_s)
            Rtheta=np.tanh(theta_s*(s+0.5))/(2.0*np.tanh(0.5*theta_s))-0.5
            C=(1.0-theta_b)*Ptheta+theta_b*Rtheta
        else:
            C=s 
        
    elif Vstretching==2:
        
        alfa=1.0
        beta=1.0
        ds=1.0/Layer_N
        if kgrid==1:
            Nlev=Np
            lev=np.arange(Layer_N+1)
            s=(lev-Layer_N)*ds
        else:
            Nlev=Layer_N
            lev=np.arange(1,Layer_N+1)-.5
            s=(lev-Layer_N)*ds
        
        if theta_s>0:
            Csur=(1.0-np.cosh(theta_s*s))/(np.cosh(theta_s)-1.0)
            if theta_b>0:
                Cbot=-1.0+np.sinh(theta_b*(s+1.0))/np.sinh(theta_b)
                weigth=(s+1.0)**alfa*(1.0+(alfa/beta)*(1.0-(s+1)**beta))
                C=weigth*Csur+(1.0-weigth)*Cbot
            else:
                C=Csur
    elif Vstretching==4:
        ds=1.0/Layer_N
        if kgrid==1:
            Nlev=Np
            lev=np.arange(Layer_N+1)
            s=(lev-Layer_N)*ds
        else:
            nlev=Layer_N
            lev=np.arange(1,Layer_N+1)-0.5
            s=(lev-Layer_N)*ds
        if theta_s>0:
            Csur=(1.0-np.cosh(theta_s*s))/(np.cosh(theta_s)-1.0)
        else:
            Csur=-s**2
        
        if theta_b>0:
            Cbot=(np.exp(theta_b*Csur)-1.0)/(1.0-np.exp(-theta_b))
            C=Cbot
        else:
            C=Csur
        
        
    elif Vstretching==5:
        if kgrid==1:
            nlev=Np
            lev=np.arange(Layer_N+1)
            s=-(lev*lev-2.0*lev*Layer_N+lev+Layer_N*Layer_N-Layer_N)/(Layer_N*Layer_N-Layer_N)-\
                0.01*(lev*lev-lev*Layer_N)/(1.0-Layer_N)
            s[0]=-1.0
        else:
            Nlev=Layer_N
            lev=np.arange(1,Layer_N+1)-0.5
            s=-(lev*lev-2.0*lev*Layer_N+lev+Layer_N*Layer_N-Layer_N)/(Layer_N*Layer_N-Layer_N)-\
                0.01*(lev*lev-lev*Layer_N)/(1.0-Layer_N)
        if theta_s>0:
            Csur=(1.0-np.cosh(theta_s*s))/(np.cosh(theta_s)-1.0)
        else:
            Csur=-s**2
        if theta_b>0:
            Cbot=(np.exp(theta_b*Csur)-1.0)/(1.0-np.exp(-theta_b))
            C=Cbot
        else:
            C=Csur
    return s,C
    
            
def ztosigma(var,z,depth):
    Ns,Mp,Lp=z.shape
    Nz=len(depth)
    vnew=np.zeros([Ns,Mp,Lp])
    for ks in range(Ns):
        sigmalev=np.squeeze(z[ks,:,:])
        thezlevs=0*sigmalev
        for kz in range(Nz):
            thezlevs[sigmalev>depth[kz]]=thezlevs[sigmalev>depth[kz]]+1
        if np.max(thezlevs)>=Nz or np.min(thezlevs)<=0:
            print("min sigma level = "+str(np.min(z))+' - min z level = '+\
                  str(np.min(depth)))
            print("max sigma level = "+str(np.max(z))+' - max z level = '+\
                  str(np.max(depth)))            
        thezlevs=thezlevs.astype('int32')
        imat,jmat=np.meshgrid(np.arange(1,Lp+1),np.arange(1,Mp+1))
        pos=Nz*Mp*(imat-1)+Nz*(jmat-1)+thezlevs
        z1,z2=depth[thezlevs-1],depth[thezlevs]
        tmp_var=var.transpose().flatten()
        v1=tmp_var[pos-1].reshape(Mp,Lp)
        v2=tmp_var[pos].reshape(Mp,Lp)
        vnew[ks,:,:]=(((v1-v2)*sigmalev+v2*z1-v1*z2)/(z1-z2))
    return vnew
        

            
            
            
            
    