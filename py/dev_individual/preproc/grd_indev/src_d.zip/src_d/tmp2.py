# -*- coding: utf-8 -*-
"""
Created on Mon Jan 30 20:28:14 2023

@author: birostris
@email : birostris36@gmail.com

Name : 
Reference :
Description :
"""

PKG_path = 'D:/Working_hub/OneDrive/base142/Factory/MantaROMS/src_d/'
import sys 
sys.path.append(PKG_path)
import JNUROMS as jr
from JNU_create import create_ini
import numpy as np
from netCDF4 import Dataset,MFDataset,date2num,num2date
import os
from scipy.interpolate import griddata
import datetime as dt
from tqdm import tqdm
import matplotlib.pyplot as plt

My_Ini='D:/Working_hub/OneDrive/base142/Factory/MantaROMS/Test_nc/Ini_soda_05d_jhlee_198002.nc'
My_Grd='D:/Working_hub/OneDrive/base142/Warehouse01/Grd_SO_05d.nc'
OGCM_PATH='D:/Working_hub/DATA_dep/SODA/'

Ini_title='test_Ini'
# My Variables
MyVar={'Layer_N':50,'Vtransform':2,'Vstretching':5,\
       'Theta_s':7,'Theta_b':0.1,'Tcline':300,'hmin':50}

# OGCM Variables
OGCMVar={'lon_rho':'xt_ocean','lat_rho':'yt_ocean','depth':'st_ocean','time':'time',\
         'lon_u':'xu_ocean','lat_u':'yu_ocean','lon_v':'xu_ocean','lat_v':'yu_ocean',
         'temp':'temp','salt':'salt','u':'u','v':'v','zeta':'ssh'}
    
OGCMS=[OGCM_PATH+'/'+i for i in os.listdir(OGCM_PATH) if i.endswith('.nc')]

# Get My Grid info
ncG=Dataset(My_Grd)
lonG,latG=ncG['lon_rho'][:],ncG['lat_rho'][:]
angle,topo,mask=ncG['angle'][:],ncG['h'][:],ncG['mask_rho'][:]
ncG.close()

atG,onG=lonG.shape
cosa,sina=np.cos(angle),np.sin(angle)

# Get OGCM Grid info
ncO=Dataset(OGCMS[0])
lonO,latO=ncO[OGCMVar['lon_rho']][:],ncO[OGCMVar['lat_rho']][:];
depthO=ncO[OGCMVar['depth']][:]
ncO.close()


# Get OGCM lon lat coordinates for slicing
lonGmax=np.max(np.abs(np.diff(lonG[0,:])))
latGmax=np.max(np.abs(np.diff(latG[:,0])))

lonOmax=np.max(np.abs(np.diff(lonO[:])))
latOmax=np.max(np.abs(np.diff(latO[:])))

lonEval=np.max([lonO[-1],lonG[0,-1]+lonOmax])
lonSval=np.min([lonO[0],lonG[0,0]+lonOmax])

latEval=np.max([latO[-1],latG[-1,0]+latOmax])
latSval=np.min([latO[0],latG[0,0]+latOmax])

lonO_co=np.where(lonO[(lonO>=lonSval-lonOmax)&(lonO<=lonEval)])[0]

latO_co=np.where(latO[(latO>=latG[0,0]-latOmax)&(latO<=latG[-1,0]+0.5)])[0]
latO_s=latO[latO_co]
lonO_s=lonO[lonO_co]

# =============================================================================
if latG[0,0]<latO_s[0]:
    OGCM_lat_diff=np.diff(latO_s[0:2].data)
    tmp_l=np.arange(latO_s[0]-OGCM_lat_diff,latG[0,0]-OGCM_lat_diff,-OGCM_lat_diff)
    tmp_array=np.full((len(tmp_l), len(lonO_s[:])), False)
    tmp_array_val=np.zeros_like(tmp_array)
    latO_s_=np.concatenate([np.flipud(tmp_l),latO_s[:]],axis=0)
   
# =============================================================================
lonO_s_m,latO_s_m=np.meshgrid(lonO_s,latO_s_)
# =============================================================================
# Process Times
tmp_time_var='time'
t_rng=['1980-02','2014-02']
My_time_ref='days since 1950-1-1 00:00:00'
OGCM_TIMES=MFDataset(OGCM_PATH+'*.nc')[tmp_time_var]
TIME_UNIT=OGCM_TIMES.units
OGCM_times=num2date(OGCM_TIMES[:],TIME_UNIT)
Tst=dt.datetime(int(t_rng[0].split('-')[0]), int(t_rng[0].split('-')[1]),1)
Ted=dt.datetime(int(t_rng[1].split('-')[0]), int(t_rng[1].split('-')[1]),28)
TIMES_co=np.where( (OGCM_times>=Tst)&(OGCM_times<=Ted) )[0]
# =============================================================================
tmp_y,tmp_m=int(t_rng[0].split('-')[0]),int(t_rng[0].split('-')[-1])
tmp_dif=date2num(dt.datetime(tmp_y,tmp_m,1),TIME_UNIT)-date2num(dt.datetime(tmp_y,tmp_m,1),My_time_ref)
Ini_time_num=(date2num(dt.datetime(tmp_y,tmp_m,1),TIME_UNIT)-tmp_dif)*86400
# Make an Inifile

# Get OGCM data for initial
import time
import pymp
from multiprocessing import Pool

# =============================================================================
# import time
# from multiprocessing import Pool

# if __name__ == '__main__':
#     ST = time.time()
#     # 멀티 쓰레딩 Pool 사용
#     pool = Pool(processes=6)  # 현재 시스템에서 사용 할 프로세스 개수
#     pool.map(tmp1, range(5))
#     pool.close()
#     pool.join()
#     ED=time.time(); TT=ED-ST
#     print(str(((TT)/60)))
# =============================================================================


def tmp1(TIMES_co):
    OGCM_Data={}#,OGCM_Mask={}
    for co in TIMES_co:
        LIST=['zeta','u','v','temp','salt']
        for i in range(len(LIST)):
            vm=LIST[i]
            print('!!! Data processing : '+vm+' !!!')
            if vm == 'zeta':
                tmp_data=np.squeeze(Dataset(OGCMS[co])[OGCMVar[vm]][co,latO_co,lonO_co])
                tmp_mask=np.invert(tmp_data.mask)
            else:
                tmp_data=np.squeeze(Dataset(OGCMS[co])[OGCMVar[vm]][co,:,latO_co,lonO_co])
                tmp_mask=np.invert(tmp_data.mask)
            
            if len(tmp_data.shape)==2:
                tmp_data=np.concatenate([tmp_array_val,tmp_data],axis=0)
                tmp_mask=np.concatenate([tmp_array,tmp_mask])
                data=griddata((lonO_s_m[tmp_mask].flatten(),latO_s_m[tmp_mask].flatten()),\
                              tmp_data[tmp_mask].flatten(),(lonO_s_m.flatten(),latO_s_m.flatten()),'nearest')
                data_ex=data.reshape(latO_s_m.shape)
                data=griddata((lonO_s_m.flatten(),latO_s_m.flatten()),\
                              data_ex.flatten(),(lonG.flatten(),latG.flatten()),'cubic')
                data=data.reshape(lonG.shape)
               
            elif len(tmp_data.shape)==3:
                data,n=np.zeros([len(depthO),atG,onG]),0
                for j,k in tqdm(zip(tmp_data,tmp_mask)):
                    tmp_data_j=np.concatenate([tmp_array_val,j],axis=0)
                    tmp_mask_k=np.concatenate([tmp_array,k])
                    data_=griddata((lonO_s_m[tmp_mask_k].flatten(),latO_s_m[tmp_mask_k].flatten()),\
                                  tmp_data_j[tmp_mask_k].flatten(),(lonO_s_m.flatten(),latO_s_m.flatten()),'nearest')
                    data_ex=data_.reshape(latO_s_m.shape)
                    data_=griddata((lonO_s_m.flatten(),latO_s_m.flatten()),\
                                  data_ex.flatten(),(lonG.flatten(),latG.flatten()),'cubic')
                    data[n]=data_.reshape(latG.shape)
                    n+=1
            OGCM_Data[vm]=data
            
                   
        # Process vector elements
        def rho2u_3d(var):
            N,Mp,Lp=var.shape
            L=Lp-1
            var_u=0.5*(var[:,:,:L]+var[:,:,1:Lp])
            return var_u
        def rho2v_3d(var):
            N,Mp,Lp=var.shape
            M=Mp-1
            var_v=0.5*(var[:,:M,:]+var[:,1:Lp,:])
            return var_v
        
        u=rho2u_3d(OGCM_Data['u']*cosa+OGCM_Data['v']*sina)
        v=rho2v_3d(OGCM_Data['v']*cosa-OGCM_Data['u']*sina)
        
        # Calculates barotropic uv
        dz=np.diff(depthO)
        u_tmp=u[:-1,:,:]+u[1:,:,:]
        v_tmp=v[:-1,:,:]+v[1:,:,:]
        dz4uv=np.zeros([len(depthO)-1,atG,onG])
        for ii in range(atG):
            for jj in range(onG):
                dz4uv[:,ii,jj]=dz
        # Barotropic velocities1
        ubar=np.sum(u_tmp*dz4uv[:,:,1:],axis=0)/depthO[-1]
        vbar=np.sum(v_tmp*dz4uv[:,1:,:],axis=0)/depthO[-1]
        
        # Process ROMS Vertical grid
        Z=np.zeros(len(depthO)+2)
        Z[0]=100;Z[1:-1]=-depthO;Z[-1]=-100000
        
        Rzeta=OGCM_Data['zeta']
        zr=jr.zlevs(MyVar['Vtransform'],MyVar['Vstretching'],MyVar['Theta_s'],\
                 MyVar['Theta_b'],MyVar['Tcline'],MyVar['Layer_N'],\
                     1,topo,Rzeta);
        zu=rho2u_3d(zr);
        zv=rho2v_3d(zr);
        zw=jr.zlevs(MyVar['Vtransform'],MyVar['Vstretching'],MyVar['Theta_s'],\
                 MyVar['Theta_b'],MyVar['Tcline'],MyVar['Layer_N'],\
                     5,topo,Rzeta);
        dzr=zw[1:,:,:]-zw[:-1,:,:]
        dzu=rho2u_3d(dzr);
        dzv=rho2v_3d(dzr);
        
        # Add a level on top and bottom with no-gradient
        temp,salt=OGCM_Data['temp'],OGCM_Data['salt']
        
        u1=np.vstack((np.expand_dims(u[0,:,:],axis=0)\
                      ,u,np.expand_dims(u[-1,:,:],axis=0)))
        v1=np.vstack((np.expand_dims(v[0,:,:],axis=0)\
                      ,v,np.expand_dims(v[-1,:,:],axis=0)))
        temp=np.vstack((np.expand_dims(temp[0,:,:],axis=0)\
                      ,temp,np.expand_dims(temp[-1,:,:],axis=0)))
        salt=np.vstack((np.expand_dims(salt[0,:,:],axis=0)\
                      ,salt,np.expand_dims(salt[-1,:,:],axis=0)))
        
        u=jr.ztosigma(np.flip(u1,axis=0),zu,np.flipud(Z));
        v=jr.ztosigma(np.flip(v1,axis=0),zv,np.flipud(Z));
        temp=jr.ztosigma(np.flip(temp,axis=0),zr,np.flipud(Z));
        salt=jr.ztosigma(np.flip(salt,axis=0),zr,np.flipud(Z));
        
        # Barotropic velocities2
        ubar_=np.sum(u*dzu,axis=0)/np.sum(dzu,axis=0)
        vbar_=np.sum(v*dzv,axis=0)/np.sum(dzv,axis=0)
        
        ncI=Dataset(My_Ini,mode='a')
        ncI['zeta'][co,:,:]=Rzeta
        # ncI['SSH'][:]=Rzeta
        ncI['temp'][co,:,:,:]=temp
        ncI['salt'][co,:,:,:]=salt
        ncI['u'][co,:,:,:]=u
        ncI['v'][co,:,:,:]=v
        ncI['ubar'][co,:,:]=ubar
        ncI['vbar'][co,:,:]=vbar
        ncI.close()

if __name__=='__main__':
    pool=Pool(processes=4)
    pool.map(tmp1,TIMES_co)
    pool.close()
    pool.join()



















