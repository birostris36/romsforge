# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 12:58:25 2022

@author: birostris
@email : birostris36@gmail.com

Name : 
Reference :
Description :
"""
import numpy as np
import math

class JNU_ROMS():


    def __init__(self):
        self.ao='d'
        
        
    def rho2uvp(self,FIELD):
        Mp,Lp=FIELD.shape
        M,L=Mp-1,Lp-1
        
        v_points=.5*(FIELD[:M,:]+FIELD[1:Mp,:])
        u_points=.5*(FIELD[:,:L]+FIELD[:,1:Lp]) 
        p_points=.5*(u_points[:M,:]+u_points[1:Mp,:])
        return u_points,v_points,p_points
    
    def get_metrics(self,latu,lonu,latv,lonv):
        Mp,L=latu.shape        
        M,Lp=latv.shape
        Lm,Mm=L-1,M-1
        
        dx,dy=np.zeros([Mp,Lp]),np.zeros([Mp,Lp])
        
        dx[:,1:L]=self.spheric_dist(latu[:,:Lm],latu[:,1:L],\
                               lonu[:,:Lm],lonu[:,1:L])

        dx[:,0]=dx[:,1];
        dx[:,Lp-1]=dx[:,L-1]
        
        dy[1:M,:]=self.spheric_dist(latv[:Mm,:],latv[1:M,:],\
                               lonv[:Mm,:],lonv[1:M,:])
        dy[0,:]=dy[1,:];
        dy[Mp-1,:]=dy[M-1,:]
        
        pm,pn=1/dx,1/dy

        dndx[1:M,1:L]=.5*(1/pn[1:M,2:Lp]-1/pn[1:M,:Lm])
        dmde[1:M,1:L]=.5*(1/pm[2:Mp,1:L]-1/pm[:Mm,1:L])
        
        dndx[0,:]=0;
        dndx[Mp-1,:]=0;
        dndx[:,0]=0;
        dndx[:,Lp-1]=0;
        dmde[0,:]=0;
        dmde[Mp-1,:]=0;
        dmde[:,0]=0;
        dmde[:,Lp-1]=0;
        
        return pm,pn,dndx,dmde
        
    def spheric_dist(self,lat1,lat2,lon1,lon2):
        import math
        # Earth Radi    
        R=6367442.76
        # Determine proper longitudinal shift.
        l=np.abs(lon2-lon1)
        l[l>=180]=360-l[l>=180]
        #  Convert Decimal degrees to radians.
        deg2rad=pi/180
        lat1=lat1*deg2rad
        lat2=lat2*deg2rad
        l=l*deg2rad
        # dist=R*math.asin(np.sqrt(((np.sin(l).*np.cos(lat2))**2)+\
        #                     (((np.sin(lat2)*np.cos(lat1))-\
        #                       (np.sin(lat1)*np.cos(lat2)*np.cos(l)))**2)))
        dist=np.array([R*math.asin(i) for i in np.sqrt(((np.sin(l)*np.cos(lat2))**2)+\
                            (((np.sin(lat2)*np.cos(lat1))-\
                              (np.sin(lat1)*np.cos(lat2)*np.cos(l)))**2)) ])
        return dist

    def get_angle(self,latu,lonu):
        A,E = 6378137.,0.081819191
        B = np.sqrt(A**2 - (A*E)**2)
        EPS= E*E/(1-E*E)
        # convert to radians
        latu=latu*pi/180     
        lonu=lonu*pi/180
        # Fixes some nasty 0/0 cases in the geoesics stuff
        latu[latu==0]=eps
        M,L=latu.shape
        # endpoints of each segment
        PHI1=latu[:M,:L-1]    
        XLAM1=lonu[:M,:L-1]
        PHI2=latu[:M,1:L]
        XLAM2=lonu[:M,1:L]
        # wiggle lines of constant lat to prevent numerical probs.
        PHI2[PHI1==PHI2]=PHI2[PHI1==PHI2]+ 1e-14
        # wiggle lines of constant lon to prevent numerical probs.
        XLAM2[XLAM1==XLAM2]=XLAM2[XLAM1==XLAM2]+ 1e-14
        # COMPUTE THE RADIUS OF CURVATURE IN THE PRIME VERTICAL FOR EACH POINT
        xnu1=A/np.sqrt(1.0-(E*np.sin(PHI1))**2) 
        xnu2=A/np.sqrt(1.0-(E*np.sin(PHI2))**2)
        # COMPUTE THE AZIMUTHS.  azim  IS THE AZIMUTH AT POINT 1 OF THE NORMAL SECTION CONTAINING THE POINT 2
        TPSI2=(1.-E*E)*np.tan(PHI2) + E*E*xnu1*np.sin(PHI1)/(xnu2*np.cos(PHI2))
        # SOME FORM OF ANGLE DIFFERENCE COMPUTED HERE??
        DLAM=XLAM2-XLAM1
        CTA12=(np.cos(PHI1)*TPSI2 - np.sin(PHI1)*np.cos(DLAM))/np.sin(DLAM)
        # azim=atan(1/CTA12)
        azim=np.array([np.atan(1/i) for i in CTA12])
        
        # GET THE QUADRANT RIGHT
        DLAM2=(abs(DLAM)<np.pi)*DLAM + (DLAM>=np.pi)*(-2*np.pi+DLAM) + \
            (DLAM<=-np.pi)*(2*np.pi+DLAM)
        azim=azim+(azim<-np.pi)*2*np.pi-(azim>=np.pi)*2*np.pi
        
        SIGN=lambda x:x/abs(x) if not x else 0 
        azim=azim+np.pi*SIGN(-azim)*( SIGN(azim) != SIGN(DLAM2) )
        angle[:,1:L]=(pi/2)-azim[:,1:L-1]
        angle[:,0]=angle[:,1]
        angle[:,L]=angle[:,L-1]
        return angle

    def add_topo(self,topo_name,lat_rng,lon_rng,pm,pn):
        # Get ROMS averaged resolution
        dx=np.mean(np.mean(1./pm))
        dy=np.mean(np.mean(1./pn))
        dx_roms=mean(np.array([dx, dy]))
        disp(['ROMS resolution : '+str(dx_roms/1000)+' km'])
        
        TOPO=Dataset(topo_name)
        TOPO_lat,TOPO_lon=TOPO['lat'][:],TOPO['lon'][:]
        TOPO_lat_co=np.where((TOPO_lat>=lat_rng[0]-1)&((TOPO_lat<=lat_rng[-1]+1)))[0]
        TOPO_lon_co=np.where((TOPO_lon>=lon_rng[0]-1)&((TOPO_lon<=lon_rng[-1]+1)))[0]
        topo=TOPO['topo'][TOPO_lat_co,TOPO_lon_co]
        x,y=TOPO_lon[TOPO_lon_co],TOPO_lat[TOPO_lat_co]
        
        # Get TOPO averaged resolution
        R=6367442.76
        deg2rad=np.pi/180
        dg=np.mean(x[1:end]-x[:end-1])
        dphi=y[1:end]-y[0:end-1]
        dy=R*deg2rad*dphi
        dx=R*deg2rad*dg*np.cos(deg2rad*y)
        dx_topo=np.mean(np.array([dx, dy]))
        print(['Topography data resolution : '+str(dx_topo/1000)+' km'])
        
        #Degrade TOPO resolution
        while dx_roms>dx_topo:
            from scipy.interpolate import interp2d, griddata
            x=.5*(x[1:]+x[:-1]);
            x=x[::2];
            y=.5*(y[1:]+y[:-1]);
            y=y[::2];
            topo=.25*(topo[1:,:-1]+topo[1:,1:]+\
                     topo[:-1,:-1]+topo[:-1,1:]);
            topo=topo[::2,::2]   
            dg=np.mean(x[1:]-x[:-1])
            dphi=y[1:]-y[:-1]
            dy=R*deg2rad*dphi
            dx=R*deg2rad*dg*np.cos(deg2rad*y)
            dx_topo=np.mean(np.array([dx,dy]))
        print(['Topography resolution halved '+str(n)+' times'])
        print(['New topography resolution : '+str(dx_topo/1000)+' km'])
        
        x_,y_=np.meshgrid(x,y)
        h_=griddata((x_.flatten(),y_.flatten()),\
                   topo.flatten(),\
                       (Lonr.flatten(),Latr.flatten()),
                   method='linear',fill_value=np.nan)
        h=h_.reshape(Lonr.shape)

        return h


        def uvp_mask(self,rmask):
            Mp,Lp=rmask.shape
            M,L=Mp-1,Lp-1
            vmask=rmask[:M,:]*rmask[1:Mp,:]
            umask=rmask[:,:L]*rmask[:,1:Lp]
            pmask=umask[:M,:]*umask[1:Mp,:]
            return ufield,vfield,pfield















